import React from 'react'

function Home() {
  return (
    <>
        <>
        <Product/>

        <Dashboard/>
        </>
    </>

  )
}

export default Login
